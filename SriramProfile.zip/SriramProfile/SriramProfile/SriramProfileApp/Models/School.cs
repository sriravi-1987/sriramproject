﻿using System.ComponentModel.DataAnnotations;

namespace EmployeeCRUD.Models
{
    public class School
    {
        [Key]
        public int Id { get; set; }
        [Required]
        [Display(Name ="School Name")]
        public string School { get; set; }
        public string University { get; set; }
        public string Certification { get; set; }        
        public string Skill { get; set; }

    }
}
